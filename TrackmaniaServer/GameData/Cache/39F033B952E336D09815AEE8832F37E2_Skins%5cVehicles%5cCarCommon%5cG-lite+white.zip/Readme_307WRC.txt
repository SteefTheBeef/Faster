23/01/2006 - version 2.0

   33333333333    00000000000   7777777777777
  3333333333333  0000000000000  7777777777777
  3333333333333  0000000000000  7777777777777
           3333  0000     0000          7777         
           3333  0000     0000          7777
      333333333  0000     0000         7777
      333333333  0000     0000         7777
      333333333  0000     0000        7777
           3333  0000     0000        7777
           3333  0000     0000       7777
  3333333333333  0000000000000       7777
  3333333333333  0000000000000      7777
   33333333333    00000000000       7777    

WWWW   WWWW   WWWW  RRRRRRRRRRRR    CCCCCCCCCCC
WWWW   WWWW   WWWW  RRRRRRRRRRRRR  CCCCCCCCCCCCC
WWWW   WWWW   WWWW  RRRRRRRRRRRRR  CCCCCCCCCCCCC
WWWW   WWWW   WWWW  RRRR     RRRR  CCCC     CCCC
WWWW   WWWW   WWWW  RRRR     RRRR  CCCC
WWWW   WWWW   WWWW  RRRRRRRRRRRRR  CCCC
WWWW  WW  WW  WWWW  RRRRRRRRRRRRR  CCCC
WWWW  WW  WW  WWWW  RRRRRRRRRRRR   CCCC
WWWW WW    WW WWWW  RRRR   RRRR    CCCC
WWWW WW    WW WWWW  RRRR   RRRR    CCCC     CCCC
 WWWWW      WWWWW   RRRR    RRRR   CCCCCCCCCCCCC
  WWWW      WWWW    RRRR     RRRR  CCCCCCCCCCCCC
  WWWW      WWWW    RRRR      RRRR  CCCCCCCCCCC

Peugeot 307 WRC for Rally (TMO)
A Trackmania Sunrise 3D Model by Tom Juenet aka Jambon,
Official WRC skin by Richard Elie aka Ricardosan.

******************************
Put this entire archive in your " ...\TMO\GameData\Skins\Vehicles\Rally\ "  directory

And now, stop reading, let's try it !
See you on the TM forums ;)

******************************

for any feedback:
Jambon : tom-juenet@wanadoo.fr
Ricardosan : ricardosan76@hotmail.com